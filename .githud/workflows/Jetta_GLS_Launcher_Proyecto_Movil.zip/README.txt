# Jetta GLS Launcher

Proyecto inicial Android para pantalla horizontal 1024x600.

## Incluye
- Pantalla horizontal tipo launcher.
- Encabezado BIENVENIDO JESUS.
- Ilustración del Jetta tomada de la referencia proporcionada.
- Panel de clima usando GPS + Open-Meteo (requiere ubicación e internet).
- Cuatro zonas: Jetta/clima, Google Maps, Torque OBD2 y Spotify.
- Los botones intentan abrir las apps instaladas; si faltan, abren su página/enlace.

## Generar APK
1. Abre esta carpeta en Android Studio (Giraffe o más reciente).
2. Espera la sincronización de Gradle.
3. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
4. El APK de prueba estará en `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar en el estéreo
Copia el APK al estéreo por USB o memoria, ábrelo desde el administrador de archivos y acepta instalar.
Después pulsa Home y elige Jetta GLS Launcher. Si Android pregunta si deseas usarlo siempre como pantalla de inicio, confirma.

## Nota
Este es un proyecto inicial de desarrollo, no un APK ya compilado. Se debe compilar con Android Studio. El clima requiere que el estéreo tenga internet y que se conceda permiso de ubicación. Los nombres de paquete de Torque y Spotify pueden variar según la versión instalada; si un acceso no abre, se ajusta con el paquete real.

## Compilar solo con celular Android (sin computadora)
Este ZIP incluye un flujo de compilación en GitHub Actions.
1. Desde Chrome en el celular, entra a https://github.com/ y crea una cuenta o inicia sesión.
2. Crea un repositorio nuevo llamado Jetta-GLS-Launcher. Para usar GitHub Actions gratis con mayor facilidad, déjalo público. No subas contraseñas ni datos personales.
3. En el repositorio, usa Add file > Upload files y sube el CONTENIDO de este ZIP (incluida la carpeta oculta .github).
4. Pulsa Commit changes. En la pestaña Actions se ejecutará "Build Jetta GLS Launcher APK".
5. Cuando termine con marca verde, abre la ejecución y descarga el artefacto "Jetta-GLS-Launcher-debug". Dentro está app-debug.apk.
6. Abre el APK en el estéreo e instala. Puede ser necesario permitir instalación desde esa fuente.

Si GitHub no muestra la carpeta .github al extraer/subir desde el teléfono, usa la opción de cargar archivos desde el navegador en modo escritorio o crea manualmente .github/workflows/android.yml con el contenido de ese archivo.
