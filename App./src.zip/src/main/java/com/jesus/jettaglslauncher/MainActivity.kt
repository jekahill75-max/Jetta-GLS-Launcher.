package com.jesus.jettaglslauncher

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var clock: TextView
    private lateinit var weather: TextView
    private lateinit var city: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now) +
                "\n" + SimpleDateFormat("EEE dd MMM yyyy", Locale("es","MX")).format(now)
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        buildDashboard()
        handler.post(tick)
        requestWeatherLocation()
    }

    private fun buildDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(2,7,15), Color.rgb(8,22,40), Color.BLACK))
        }
        val header = TextView(this).apply {
            text = "◉     BIENVENIDO JESUS     ◉"
            setTextColor(Color.WHITE); textSize = 26f; typeface = Typeface.create("sans-serif", Typeface.BOLD_ITALIC)
            gravity = Gravity.CENTER; setPadding(4, 2, 4, 8)
        }
        root.addView(header, LinearLayout.LayoutParams(-1, 52))
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(top, LinearLayout.LayoutParams(-1, 0, 1.05f))
        root.addView(bottom, LinearLayout.LayoutParams(-1, 0, 0.95f))

        val carPanel = panel()
        val carArea = FrameLayout(this)
        val car = ImageView(this).apply {
            setImageResource(com.jesus.jettaglslauncher.R.drawable.jetta_front)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.TRANSPARENT)
        }
        carArea.addView(car, FrameLayout.LayoutParams(-1, -1))
        val climateBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(6, 4, 6, 4)
            background = GradientDrawable().apply {
                setColor(0xAA071322.toInt()); cornerRadius = 16f
                setStroke(2, 0xFF168DFF.toInt())
            }
        }
        weather = TextView(this).apply { text = "Clima\nBuscando ubicación…"; textSize = 17f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; typeface=Typeface.DEFAULT_BOLD }
        city = TextView(this).apply { text = "Ubicación del estéreo"; textSize=11f; setTextColor(0xFFB9DFFF.toInt()); gravity=Gravity.CENTER }
        climateBox.addView(weather)
        climateBox.addView(city)
        val climateParams = FrameLayout.LayoutParams(190, 78, Gravity.TOP or Gravity.END).apply { setMargins(0, 8, 8, 0) }
        carArea.addView(climateBox, climateParams)
        carPanel.addView(carArea, LinearLayout.LayoutParams(-1,-1))
        top.addView(carPanel, LinearLayout.LayoutParams(0,-1,1.08f))

        val maps = appPanel("GOOGLE MAPS", "🗺", "Abrir navegación") {
            launchApp("com.google.android.apps.maps", "https://maps.google.com")
        }
        top.addView(maps, LinearLayout.LayoutParams(0,-1,0.92f))

        val torque = appPanel("TORQUE OBD2", "⚙", "Diagnóstico del Jetta") {
            launchApp("org.prowl.torque", "https://play.google.com/store/apps/details?id=org.prowl.torque")
        }
        val spotify = appPanel("SPOTIFY", "♫", "Música") {
            launchApp("com.spotify.music", "https://open.spotify.com")
        }
        bottom.addView(torque, LinearLayout.LayoutParams(0,-1,1f))
        bottom.addView(spotify, LinearLayout.LayoutParams(0,-1,1f))
        setContentView(root)
    }

    private fun panel(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(5,5,5,5)
        background = GradientDrawable().apply {
            setColor(0xFF07111F.toInt()); cornerRadius=20f
            setStroke(3, 0xFF078FFF.toInt())
        }
    }

    private fun appPanel(title: String, symbol: String, subtitle: String, action: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(8,8,8,8)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF101E31.toInt(), 0xFF03070D.toInt())).apply {
                cornerRadius=20f; setStroke(3, 0xFF078FFF.toInt())
            }
            isClickable = true; isFocusable = true; setOnClickListener { action() }
        }
        val icon = TextView(this).apply {
            text = symbol; textSize = 54f; gravity=Gravity.CENTER
            setTextColor(when(title) { "SPOTIFY" -> 0xFF1ED760.toInt(); "TORQUE OBD2" -> 0xFFFFC400.toInt(); else -> Color.WHITE })
        }
        val label = TextView(this).apply {
            text=title; textSize=22f; typeface=Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity=Gravity.CENTER
        }
        val sub = TextView(this).apply { text=subtitle; textSize=12f; setTextColor(0xFFB9DFFF.toInt()); gravity=Gravity.CENTER }
        box.addView(icon, LinearLayout.LayoutParams(-1,0,1f))
        box.addView(label); box.addView(sub)
        val lp = LinearLayout.LayoutParams(0,-1,1f).apply { setMargins(5,6,5,4) }
        box.layoutParams = lp
        return box
    }

    private fun launchApp(packageName: String, fallback: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        try {
            if (launch != null) startActivity(launch)
            else startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(fallback)))
        } catch (_: Exception) {
            Toast.makeText(this, "No se pudo abrir la aplicación", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestWeatherLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 44)
            return
        }
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val loc: Location? = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
                .mapNotNull { provider -> try { lm.getLastKnownLocation(provider) } catch (_: Exception) { null } }
                .maxByOrNull { it.time }
            if (loc != null) loadWeather(loc.latitude, loc.longitude)
            else {
                weather.text = "Clima no disponible"
                city.text = "Activa la ubicación del estéreo"
            }
        } catch (_: Exception) {
            weather.text = "Clima no disponible"
            city.text = "Revisa permisos de ubicación"
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 44 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) requestWeatherLocation()
    }

    private fun loadWeather(lat: Double, lon: Double) {
        thread {
            try {
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto")
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout=7000; c.readTimeout=7000
                val body = c.inputStream.bufferedReader().use { it.readText() }
                c.disconnect()
                val temp = Regex("\"temperature_2m\"\\s*:\\s*(-?[0-9.]+)").find(body)?.groupValues?.get(1)
                val code = Regex("\"weather_code\"\\s*:\\s*(\\d+)").find(body)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                val desc = when(code) { 0 -> "Despejado"; 1,2 -> "Poco nublado"; 3 -> "Nublado"; 45,48 -> "Niebla"; in 51..67 -> "Lluvia"; in 71..77 -> "Nieve"; in 80..82 -> "Chubascos"; in 95..99 -> "Tormenta"; else -> "Condición variable" }
                runOnUiThread {
                    weather.text = "${temp ?: "--"}°C\n$desc"
                    city.text = "Clima local • GPS"
                }
            } catch (_: Exception) {
                runOnUiThread { weather.text = "Clima no disponible"; city.text = "Comprueba conexión a internet" }
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }
}
